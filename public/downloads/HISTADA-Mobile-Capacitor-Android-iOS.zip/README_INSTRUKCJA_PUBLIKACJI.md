# HISTADA · WERSJA NATYWNA (ANDROID & IOS)
Pakiet publikacji mobilnej dla Google Play Store, Apple App Store oraz bezpośredniej instalacji sideload.

## 📱 ANDROID:
### 1. Bezpośrednia instalacja na telefonie (Sideload APK):
- Pobierz plik `HISTADA_v2.0_Android_Universal.apk` bezpośrednio na telefon.
- Wejdź w Ustawienia -> Bezpieczeństwo i zaznacz "Zezwalaj na instalowanie aplikacji z nieznanych źródeł".
- Kliknij pobrany plik APK i wybierz "Zainstaluj".
- Gotowe! Aplikacja działa w 100% offline bez internetu.

### 2. Publikacja w Google Play Store:
```bash
npm install
npx cap sync android
cd android
./gradlew bundleRelease
```
Wygenerowany plik `app-release.aab` wgraj do konsoli Google Play Console.

---

## 🍏 APPLE IOS (IPHONE / IPAD):
### 1. Bezpośrednia instalacja (Sideload bez Maca):
- Użyj darmowego programu **AltStore** (https://altstore.io) lub **Sideloadly** (https://sideloadly.io).
- Podłącz iPhone kablem USB do komputera PC lub Mac.
- Przeciągnij plik `HISTADA_v2.0_iOS_Package.ipa` i podaj swój darmowy Apple ID.
- Aplikacja zostanie zainstalowana na Twoim iPhone z pełnym dostępem do aparatu (skaner run) i dźwięku!

### 2. Publikacja w Apple App Store / TestFlight:
```bash
npm install
npx cap sync ios
npx cap open ios
```
W Xcode wybierz "Product -> Archive" i wyślij kompilację do App Store Connect.
